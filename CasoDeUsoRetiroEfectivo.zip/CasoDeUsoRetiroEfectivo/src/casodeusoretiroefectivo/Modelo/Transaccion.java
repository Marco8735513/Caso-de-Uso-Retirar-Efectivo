/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package casodeusoretiroefectivo.Modelo;

/**
 *
 * @author marco
 */
public class Transaccion {

    private double montoRetirado;
    private double comision;
    private double montoCobrar; // montoRetirado + comision

    public Transaccion(double montoRetirado) {
        this.montoRetirado = montoRetirado;
        // La lógica de negocio: calcular la comisión
        this.comision = calcularComision(montoRetirado);
        this.montoCobrar = montoRetirado + this.comision;
    }

    public double calcularComision(double monto) {
        // Lógica de la comisión: 2% del monto o una tarifa fija, por ejemplo
        return monto * 0.02;
    }

    public boolean confirmar(Cuenta cuenta) {
        // Lógica de validación final y débito
        if (cuenta.obtenerSaldo() >= this.montoCobrar) {
            cuenta.actualizarSaldo(this.montoCobrar);
            return true;
        } else {
            return false; // Saldo insuficiente
        }
    }

    // Getters
    public double getMontoRetirado() {
        return montoRetirado;
    }

    public double getComision() {
        return comision;
    }

    public double getMontoCobrar() {
        return montoCobrar;
    }
}
