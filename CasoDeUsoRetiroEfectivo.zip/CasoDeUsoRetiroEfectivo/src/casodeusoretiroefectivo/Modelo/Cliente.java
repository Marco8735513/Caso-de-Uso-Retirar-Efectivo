/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package casodeusoretiroefectivo.Modelo;

/**
 *
 * @author marco
 */
public class Cliente {

    private int id;
    private String nombre;

    public Cliente(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public boolean iniciarSesion(String tarjeta, String pin) {
        // Lógica de validación real (simulada)
        System.out.println("Validando tarjeta y PIN para el cliente: " + nombre);
        return true;
    }

    // Getters
    public String getNombre() {
        return nombre;
    }
}
