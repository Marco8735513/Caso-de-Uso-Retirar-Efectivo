/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package casodeusoretiroefectivo.Modelo;

/**
 *
 * @author marco
 */
public class Cuenta {

    private String numCuenta;
    private double saldoActual;
    private String ultimos4Digitos;

    public Cuenta(String numCuenta, double saldoActual) {
        this.numCuenta = numCuenta;
        this.saldoActual = saldoActual;
        this.ultimos4Digitos = numCuenta.substring(numCuenta.length() - 4);
    }

    public double obtenerSaldo() {
        return saldoActual;
    }

    public void actualizarSaldo(double monto) {
        // La lógica de negocio real (debita el saldo)
        this.saldoActual -= monto;
    }

    // Getters
    public String getUltimos4Digitos() {
        return ultimos4Digitos;
    }
}
