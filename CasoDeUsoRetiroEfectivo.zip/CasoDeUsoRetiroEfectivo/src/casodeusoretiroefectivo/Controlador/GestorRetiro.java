/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package casodeusoretiroefectivo.Controlador;

import casodeusoretiroefectivo.Modelo.Cliente;
import casodeusoretiroefectivo.Modelo.Cuenta;
import casodeusoretiroefectivo.Modelo.Transaccion;
import casodeusoretiroefectivo.Vista.CajeroAutomatico;

/**
 *
 * @author marco
 */
public class GestorRetiro {

    private Cliente clienteActual;
    private Cuenta cuentaActual;
    private CajeroAutomatico vista;

    public GestorRetiro(Cliente cliente, Cuenta cuenta, CajeroAutomatico vista) {
        this.clienteActual = cliente;
        this.cuentaActual = cuenta;
        this.vista = vista;
    }

    // MÉTODO PRINCIPAL QUE INICIA Y ORQUESTA EL FLUJO
    public void iniciarRetiro() {
        // 1. Iniciar: La Vista le pide al Controlador que empiece
        if (!clienteActual.iniciarSesion("12345", "1111")) {
            vista.mostrarError("Error de autenticación.");
            return;
        }

        // 2. Controlador le pide a la Vista que muestre las opciones
        vista.mostrarCantidades();

        // 3. Controlador capta la selección (simulada)
        double montoSeleccionado = vista.solicitarMonto();

        // 4. Controlador crea la Transacción (Modelo) para calcular comisión
        Transaccion transaccion = new Transaccion(montoSeleccionado);

        // 5. Controlador le pide a la Vista que muestre el estado preliminar
        vista.mostrarEstadoCuenta(
                clienteActual.getNombre(),
                cuentaActual.obtenerSaldo(),
                transaccion
        );

        // 6. El cliente selecciona "Retirar Efectivo" (Simulado por la siguiente llamada)
        confirmarTransaccion(transaccion);
    }

    public void confirmarTransaccion(Transaccion transaccion) {
        // 7. Controlador usa la lógica del Modelo para finalizar el débito
        boolean exito = transaccion.confirmar(cuentaActual);

        // 8. Controlador determina la respuesta de la Vista
        if (exito) {
            vista.generarRecibo(clienteActual.getNombre(), cuentaActual, transaccion);
        } else {
            vista.mostrarError("Saldo insuficiente o error de procesamiento.");
        }
    }
}
