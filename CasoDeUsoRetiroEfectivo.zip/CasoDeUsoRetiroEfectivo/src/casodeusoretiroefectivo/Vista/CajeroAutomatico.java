/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package casodeusoretiroefectivo.Vista;

import casodeusoretiroefectivo.Modelo.Cuenta;
import casodeusoretiroefectivo.Modelo.Transaccion;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author marco
 */
public class CajeroAutomatico {

    // Propiedad interna (privada, como se corrigió)
    private List<Double> montosDisp = Arrays.asList(200.00, 400.00, 600.00, 1000.00);

    public void mostrarCantidades() {
        System.out.println("\n--- PANTALLA DE RETIRO ---");
        System.out.println("Por favor, seleccione un monto (múltiplos de 200.00):");
        for (Double monto : montosDisp) {
            System.out.println("- $" + monto);
        }
    }

    // Este método toma los datos de la Transaccion y la Cuenta para mostrarlos
    public void mostrarEstadoCuenta(String nombreCliente, double saldoActual, Transaccion transaccion) {
        System.out.println("\n--- ESTADO DE CUENTA PRELIMINAR (Zona Derecha) ---");
        System.out.println("Cliente: " + nombreCliente);
        System.out.println("Saldo Actual: $" + saldoActual);
        System.out.println("----------------------------------------");
        System.out.println("Cantidad a Retirar: $" + transaccion.getMontoRetirado());
        System.out.println("Comisión por Retiro: $" + transaccion.getComision());
        System.out.println("----------------------------------------");
        System.out.println("Monto Final (a debitar): $" + transaccion.getMontoCobrar());
        System.out.println("Presione [RETIRAR EFECTIVO] para confirmar.");
    }

    public void generarRecibo(String nombreCliente, Cuenta cuenta, Transaccion transaccion) {
        System.out.println("\n--- RECIBO DE RETIRO (Zona Derecha) ---");
        System.out.println("----------------------------------------");
        System.out.println("Cuenta (últimos 4): " + cuenta.getUltimos4Digitos());
        System.out.println("Nombre: " + nombreCliente);
        System.out.println("Cantidad Retirada: $" + transaccion.getMontoRetirado());
        System.out.println("Comisión Cobrada: $" + transaccion.getComision());
        System.out.println("Nuevo Saldo: $" + cuenta.obtenerSaldo());
        System.out.println("¡Transacción Exitosa! Retire su efectivo.");
        System.out.println("----------------------------------------");
    }

    public void mostrarError(String mensaje) {
        System.err.println("\n[ERROR] " + mensaje);
    }

    // Método simulado para capturar la selección del cliente (la entrada del usuario)
    public double solicitarMonto() {
        // En una aplicación real, aquí usarías Scanner o una GUI
        // Simulamos que el cliente selecciona 600.00
        return 600.00;
    }
}
