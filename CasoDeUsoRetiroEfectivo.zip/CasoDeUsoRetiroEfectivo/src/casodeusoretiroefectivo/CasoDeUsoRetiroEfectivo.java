/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package casodeusoretiroefectivo;

import casodeusoretiroefectivo.Controlador.GestorRetiro;
import casodeusoretiroefectivo.Modelo.Cliente;
import casodeusoretiroefectivo.Modelo.Cuenta;
import casodeusoretiroefectivo.Vista.CajeroAutomatico;

/**
 *
 * @author marco
 */
public class CasoDeUsoRetiroEfectivo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     // 1. CREAR INSTANCIAS DEL MODELO
        Cliente juan = new Cliente(1, "Juan Pérez");
        Cuenta cuentaJuan = new Cuenta("1234567890", 2500.00); // Saldo inicial: 2500.00

        // 2. CREAR INSTANCIA DE LA VISTA
        CajeroAutomatico atm = new CajeroAutomatico();

        // 3. CREAR INSTANCIA DEL CONTROLADOR, inyectando las dependencias
        GestorRetiro controlador = new GestorRetiro(juan, cuentaJuan, atm);

        // 4. INICIAR EL FLUJO
        controlador.iniciarRetiro();
    }
    
}
